#ifndef GLOBAL_RESOURSE_H
#define GLOBAL_RESOURSE_H

#include "BluetoothLogger.h"
#include <stdio.h>
#include <string.h>

extern unit::BluetoothLogger* gBluetoothLogger;

#endif
