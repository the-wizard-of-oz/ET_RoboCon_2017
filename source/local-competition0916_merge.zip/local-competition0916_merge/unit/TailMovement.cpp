#include "TailMovement.h"
#include "../hardware_setting.h"
#include "ev3api.h"
#include <math.h>


namespace unit
{
	TailMovement::TailMovement(BalancingRunnerZERO* balancingRunnerZERO, MotorController* motorController, GyroMonitor* gyroMonitor)
		:mBalancingRunnerZERO(balancingRunnerZERO)
		,mMotorController(motorController)
		,mTailMotor(nullptr)
		, mGyroMonitor(gyroMonitor)
	{
		mTailMotor = new ev3api::Motor(PORT_TAIL_MOTOR);
		mStateChange = false;
		mState = TAIL_INITIALIZE;	
		mStateRun = WAIT_BEFORE_RUN;
		mWaitTimer = 0;
		mI = 0;
	}

	TailMovement::~TailMovement()
	{
		delete mTailMotor;
	}

	bool TailMovement::shiftTailToStop()
	{
		bool isComplete = false;
		int direction = NO_STAIRING;
		int angleVelocity;

		switch (mState)
		{
		case TAIL_INITIALIZE:
			mTailMotor->reset();
			mBalancingRunnerZERO->move(direction, ZERO_SPEED);
			mState = TAIL_DOWN;
			break;

		case TAIL_DOWN:
			mBalancingRunnerZERO->move(direction, ZERO_SPEED);
			mGyroMonitor->getAnglerVelocity(angleVelocity);
			if (isTailOnPosition((float)STOP_ANGLE, TAIL_SPEED_DIFF_MODE) && angleVelocity>THRESHOLD_STOP) mState = TAIL_STOP;
			break;

		case TAIL_STOP:
			mMotorController->rotateMotors(ZERO_SPEED, ZERO_SPEED);
			if (isTailOnPosition((float)STOP_ANGLE, TAIL_SPEED_DIFF_MODE)) 	mState = TAIL_SET_POSITION;
			break;	

		case TAIL_SET_POSITION:
			isTailOnPosition((float)SET_ANGLE, TAIL_SPEED_MIDDLE);
			if (isWait(WAIT_TIME)) mState = TAIL_WAIT_SET;
			break;
			
		case TAIL_WAIT_SET:
			isTailOnPosition((float)SET_ANGLE, TAIL_SPEED_DIFF_MODE);
			if (isWait(WAIT_TIME_DOUBLE)) mState = TAIL_MOVE_POSITION;
			break;

		case TAIL_MOVE_POSITION:
			isTailOnPosition((float)MOVE_ANGLE, TAIL_SPEED_MIDDLE);
			if (isWait(WAIT_TIME)) mState = TAIL_WAIT_MOVE;
			break;

		case TAIL_WAIT_MOVE:
			isTailOnPosition((float)MOVE_ANGLE, TAIL_SPEED_DIFF_MODE);
			if (isWait(WAIT_TIME_DOUBLE)) mState = MOVEMENT_COMPLETE;
			break;

		case MOVEMENT_COMPLETE:
			mMotorController->rotateMotors(ZERO_SPEED, ZERO_SPEED);
			mTailMotor->setPWM(0);
			isComplete = true;
			break;

		default:
			mState = TAIL_DOWN;
			break;

		case FRONT_A_WHILE:
			mBalancingRunnerZERO->move(direction, ZERO_SPEED);
			mGyroMonitor->getAnglerVelocity(angleVelocity);
			if (angleVelocity>-1 * THRESHOLD_STOP)
			{
				mMotorController->rotateMotors(MIDDLE, MIDDLE);
				mState = BACK_A_WHILE;
			}

			break;

		case BACK_A_WHILE:
			direction = 0;
			mMotorController->rotateMotors(HIGH_MIDDLE *-1, HIGH_MIDDLE *-1);
			if (isWait(BACK_TIME)) mState = TAIL_STOP;
			break;
		}

		return isComplete;
	}

	bool TailMovement::shiftTail(int angle, int speed)
	{
		bool isComplete = false;
		if (isTailOnPosition((float)angle, speed)) isComplete = 1;

		return isComplete;
	}

	void TailMovement::TailRun(int speed)
	{

		switch (mStateRun)
		{
		case WAIT_BEFORE_RUN:
			isTailOnPosition((float)MOVE_ANGLE, TAIL_SPEED_MIDDLE);
			if (isWait(SETTLED_TIME)) mStateRun = TAIL_RUN_MODE;
			break;

		case TAIL_SET_MODE:
			if (isTailOnPosition((float)MOVE_ANGLE, TAIL_SPEED_MIDDLE)) mStateRun = TAIL_RUN_MODE;
			break;

		case TAIL_RUN_MODE:
			mMotorController->rotateMotors(speed, speed);
			break;

		default :
			mStateRun = WAIT_BEFORE_RUN;
			break;
		}
		
	}
	void TailMovement::TailRunKeepPosture(int speed)
	{
		
		switch (mStateRun)
		{
		case WAIT_BEFORE_RUN:
			isTailOnPosition((float)SET_ANGLE, TAIL_SPEED_DIFF_MODE);
			if (mWaitTimer > SETTLED_TIME)mStateRun = TAIL_RUN_MODE;
			else mWaitTimer++;
			break;

		case TAIL_RUN_MODE:
			isTailOnPosition((float)SET_ANGLE, TAIL_SPEED_DIFF_MODE);
			mMotorController->rotateMotors(speed, speed);
			break;

		default:
			mStateRun = WAIT_BEFORE_RUN;
			break;
		}

	}
	bool TailMovement::TailTurn360()
	{

		switch (mStateTurn)
		{
		case WAIT_BEFORE_RUN:
			isTailOnPosition((float)SET_ANGLE, TAIL_SPEED_MIDDLE);
			if (mWaitTimer > SETTLED_TIME)mStateTurn = TAIL_SET_MODE;
			else mWaitTimer++;
			break;

		case TAIL_SET_MODE:
			if (isTailOnPosition((float)MOVE_ANGLE, TAIL_SPEED_MIDDLE))
			{
				mStateTurn = TAIL_RUN_MODE;
				mMotorController->getEncoderCounts(mTurnStartRight, mTurnStartLeft);
			}
			break;

		case TAIL_TURN_MODE:
			mMotorController->rotateMotors(SLOW, -1*SLOW);
			if (isTurn(STEP_TURN_360)) mStateTurn = TURN_COMPLETE;
			break;

		case TURN_COMPLETE:
			break;

		default:
			mStateTurn = WAIT_BEFORE_RUN;
			break;
		}
		if (mStateTurn == TURN_COMPLETE)
		{
			mStateTurn = WAIT_BEFORE_RUN;
			return 1;
		}
		return 0;

	}

	bool TailMovement::TailTurnLeft90()
	{
		switch (mStateTurn)
		{
		case WAIT_BEFORE_RUN:
			isTailOnPosition((float)SET_ANGLE, TAIL_SPEED_MIDDLE);
			if (mWaitTimer > SETTLED_TIME)mStateTurn = TAIL_SET_MODE;
			else mWaitTimer++;
			break;

		case TAIL_SET_MODE:
			if (isTailOnPosition((float)MOVE_ANGLE, TAIL_SPEED_MIDDLE))
			{
				mStateTurn = TAIL_RUN_MODE;
				mMotorController->getEncoderCounts(mTurnStartRight, mTurnStartLeft);
			}
			break;

		case TAIL_TURN_MODE:
			mMotorController->rotateMotors(SLOW, -1 * SLOW);
			if (isTurn(STEP_TURN_90)) mStateTurn = TURN_COMPLETE;
			break;

		case TURN_COMPLETE:
			break;

		default:
			mStateTurn = WAIT_BEFORE_RUN;
			break;
		}
		if (mStateTurn == TURN_COMPLETE)
		{
			mStateTurn = WAIT_BEFORE_RUN;
			return 1;
		}
		return 0;

	}

	bool TailMovement::returnToBalanceRun()
	{
		int direction = 0;

		switch (mStateReturn)
		{
		case STOP_POSITION:
			mMotorController->rotateMotors(ZERO_SPEED, ZERO_SPEED);
			if (isTailOnPosition((float)STOP_ANGLE, TAIL_SPEED_DIFF_MODE))
			{
				mStateReturn = WAIT_POSITION_SETTLE;
			}
			break;
		case WAIT_POSITION_SETTLE:
			if (mWaitTimer > SETTLED_TIME)
			{
				mStateReturn = START_POSITION;
				mWaitTimer = 0;
				mBalancingRunnerZERO->initializeDeviceAndLibrary();
			}
			else
			{
				isTailOnPosition((float)STOP_ANGLE, TAIL_SPEED_DIFF_MODE);
				mWaitTimer++;
			}
			break;

		case START_POSITION:
			mBalancingRunnerZERO->move(direction, ZERO_SPEED);
			if (isTailOnPosition((float)RUN_ANGLE, TAIL_SPEED_SLOW))
			{
				mStateReturn = RETURN_COMPLETE;
			}
			break;

		case RETURN_COMPLETE:
			mStateReturn = STOP_POSITION;
			return 1;
			break;

		default:
			mStateReturn = STOP_POSITION;
			break;
		}
		return 0;

	}

	bool TailMovement::isTailOnPosition(float targetDegree, int PWMSpeed)
	{
		float diff = targetDegree - (float)mTailMotor->getCount();
		if (diff == 0)
		{
			mTailMotor->setPWM(0);
			mI = 0;
			return true;
		}
		else
		{
			if (PWMSpeed == TAIL_SPEED_DIFF_MODE) PWMSpeed = TAIL_SPEED_MIDDLE * (1 - 1 / diff) + mI / I_CONSTANT + 1;
			if(diff<0)PWMSpeed = PWMSpeed * -1;
			mTailMotor->setPWM(PWMSpeed);
			mI += PWMSpeed;
			return false;
		}

	}

	bool TailMovement::isTurn(int angle)
	{
		int right;
		int left;

		mMotorController->getEncoderCounts(right, left);
		if (right > mTurnStartRight + angle && left < mTurnStartLeft - angle) return 1;
		return 0;
	}
	void  TailMovement::stateReset()
	{
		mStateRun = WAIT_BEFORE_RUN;
		mStateTurn = WAIT_BEFORE_RUN;
		mI = 0;
	}
	bool TailMovement::isWait(int time)
	{
		bool wait = false;

		switch (mStateTimer)
		{
		case INITIALIZE_TIMER:
			mWaitTimer = 0;
			mStateTimer = COUNT_UP;
			break;
		case COUNT_UP:
			if (mWaitTimer > time)mStateTimer = FINALIZE_TIMER;
			mWaitTimer++;
			break;
		case FINALIZE_TIMER:
			ev3_speaker_play_tone(NOTE_C4, 1);
			mStateTimer = INITIALIZE_TIMER;
			wait = true;
			break;
		default:
			mStateTimer = INITIALIZE_TIMER;
			break;
		}
		return wait;
	}
}

