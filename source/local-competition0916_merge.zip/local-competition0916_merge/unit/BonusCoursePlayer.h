//*********************************************
//�w�b�_�[
//
//
//*********************************************
#ifndef BONUS_COURSE_PLAYER_H
#define BONUS_COURSE_PLAYER_H

#include "StairPlayer.h"
#include "GaragePlayer.h"
#include "LookUpGatePlayer.h"


//�^�X�N�؂�ւ��p
#define TASK_UNDEFINED		0
#define TASK_STAIR			1
#define TASK_LOOKUP_GATE	2
#define TASK_GARAGE			3
#define TASK_COMPLETE		4

#define DEBUG_TASK_START	10
namespace unit
{
	class BonusCoursePlayer
	{
	public:
		BonusCoursePlayer(unit::StairPlayer* stairPlayer, unit::LookUpGatePlayer* lookUpGatePlayer, unit::GaragePlayer* garagePlayer);

		int ismState();

		void execute();

	private:
		int	mState;
		unit::StairPlayer* mStairPlayer;
		unit::LookUpGatePlayer* mLookUpGatePlayer;
		unit::GaragePlayer* mGaragePlayer;

	};
}
#endif
