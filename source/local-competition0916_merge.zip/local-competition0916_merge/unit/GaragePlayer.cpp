#include "GaragePlayer.h"

namespace unit
{
	GaragePlayer::GaragePlayer(BalancingRunnerZERO* balancingRunnerZERO, GrayTraceTurn* grayTraceTurn,  DistanceMeter* distanceMeter, MotorController* motorController, TailMovement* tailMovement)
		:mBalancingRunnerZERO(balancingRunnerZERO),
		mGrayTraceTurn(grayTraceTurn),
		mDistanceMeter(distanceMeter), 
		mMotorController(motorController),
		mTailMovement(tailMovement)
	{
		mState = RESET_DISTANCE_METER;
		mDistanceMeter->resetMeter();
			
	}

	GaragePlayer::~GaragePlayer()
	{

	}

	bool GaragePlayer::execute()
	{
		int right = 0;
		int left = 0;

		switch (mState)
		{
		case RESET_DISTANCE_METER:
			mMotorController->getEncoderCounts(right, left);
			mDistanceMeter->update(right, left);
			mDistanceMeter->resetMeter();
			mState = CHANGE_POSTURE;
			break;

		case CHANGE_POSTURE:
			mTailMovement->TailRunKeepPosture(ZERO_SPEED);
			if (mTailMovement->shiftTail(SET_ANGLE, TAIL_SPEED_MIDDLE))mState = TO_GARAGE;
			break;

		case TO_GARAGE:
			mTailMovement->TailRunKeepPosture(MIDDLE);
			mMotorController->getEncoderCounts(right, left);
			mDistanceMeter->update(right, left);
			if (mDistanceMeter->getDistance() > GARAGE_DISTANCE) mState = SET_POSITION;
			break;

		case SET_POSITION:
			mTailMovement->TailRunKeepPosture(SLOW);
			mMotorController->getEncoderCounts(right, left);
			mDistanceMeter->update(right, left);
			if (mDistanceMeter->getDistance() > GARAGE_SET) mState = GARAGE_STOP;
			break;

		case GARAGE_STOP:
			mMotorController->rotateMotors(ZERO_SPEED, ZERO_SPEED);
			mTailMovement->shiftTail(SET_ANGLE, TAIL_SPEED_SLOW);
			break;

		default:
			mState = TO_GARAGE;
			break;
		}
		return 0;
	}
}
