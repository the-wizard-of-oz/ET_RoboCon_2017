//*************************************************
//Run4mAndStop���g
//
//
//
//*************************************************

#include "ev3api.h"
#include "BonusCoursePlayer.h"

namespace unit
{
	//�R���X�g���N�^
	BonusCoursePlayer::BonusCoursePlayer(
		StairPlayer* stairPlayer,
		LookUpGatePlayer* lookUpGatePlayer,
		GaragePlayer* garagePlayer)
		: mStairPlayer(stairPlayer)
		, mLookUpGatePlayer(lookUpGatePlayer)
		, mGaragePlayer(garagePlayer)
	{
		mState = TASK_LOOKUP_GATE;
		//mState = TASK_STAIR;
	}

	void BonusCoursePlayer::execute()
	{


		switch (mState)
		{
		case TASK_UNDEFINED:
			mState = TASK_STAIR;
			//mState = DEBUG_TASK_START;
			break;

		case TASK_STAIR:
			if (mStairPlayer->execute()) mState = TASK_GARAGE;
			break;

		case TASK_LOOKUP_GATE:
			if (mLookUpGatePlayer->execute()) mState = TASK_GARAGE;
			break;

		case TASK_GARAGE:
			if (mGaragePlayer->execute()) mState = TASK_COMPLETE;
			break;

		case TASK_COMPLETE:
			break;

		default:
			mState = TASK_UNDEFINED;
			break;
		}

	}


	int BonusCoursePlayer::ismState()
	{
		return mState;
	}
}