#ifndef EV3APIWRAPPER_BATTERY_H
#define EV3APIWRAPPER_BATTERY_H

namespace unit
{
	class Battery
	{
	public:
		int Ev3_Battery_Voltage_mV();
	};
}  // namespace unit
#endif
