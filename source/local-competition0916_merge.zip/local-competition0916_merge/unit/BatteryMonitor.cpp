#include "BatteryMonitor.h"

namespace unit
{
	BatteryMonitor::BatteryMonitor()
	{
	}

	void BatteryMonitor::getBatteryVoltageMv(int& val)
	{
		val = mBattery.Ev3_Battery_Voltage_mV();
	}
}  // namespace unit
