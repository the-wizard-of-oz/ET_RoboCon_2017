#include "BatteryDriver.h"

namespace unit
{
	int BatteryDriver::Ev3_Battery_Voltage_mV()
	{
		return mBattery.Ev3_Battery_Voltage_mV();
	}
}  // namespace unit
