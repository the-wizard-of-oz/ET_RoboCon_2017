#include "ISequence.h"

namespace unit
{
	ISequence::ISequence()
	{
	}
	
	ISequence::~ISequence()
	{
	}
}  // namespace unit
