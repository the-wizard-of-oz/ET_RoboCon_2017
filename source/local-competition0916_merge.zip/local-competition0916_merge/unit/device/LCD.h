#ifndef UNIT_LCD_H
#define UNIT_LCD_H

#include "ev3api.h"

namespace unit
{
	class LCD
	{
	public:
		void display(char* str);
	};
}  // namespace unit
#endif
