#include "StairPlayer.h"

namespace unit
{
	StairPlayer::StairPlayer(BalancingRunnerZERO* balancingRunnerZERO, FindStair* findStair, TailMovement* tailMovement, DistanceMeter* distanceMeter, MotorController* motorController)
		:mBalancingRunnerZERO(balancingRunnerZERO)
		, mFindStair(findStair)
		, mTailMovement(tailMovement)
		, mDistanceMeter(distanceMeter)
		, mMotorController(motorController)

	{
		int right = 0;
		int left = 0;
		//mState = FIND_1ST_STAIR;
		mState = FOR_TEST;
		mDistanceMeter->resetMeter();
		mMotorController->getEncoderCounts(right, left);
		mDistanceMeter->update(right, left);
		mWaitTimer = 0;

	}
	StairPlayer::~StairPlayer()
	{

	}

	bool StairPlayer::execute()
	{
		int direction = 0;
		int right = 0;
		int left = 0;

		switch (mState)
		{
		case FOR_TEST:
			mBalancingRunnerZERO->move(direction, MIDDLE);
			mMotorController->getEncoderCounts(right, left);
			mDistanceMeter->update(right, left);
			if (mDistanceMeter->getDistance() > TEST_DISTANCE)
			{
				mState = FIND_1ST_STAIR;
				mWaitTimer = 0;
				mDistanceMeter->resetMeter();
				mDistanceMeter->update(right, left);
			}
			break;

		case FIND_1ST_STAIR:
			mBalancingRunnerZERO->move(direction, MIDDLE);
			mMotorController->getEncoderCounts(right, left);
			mDistanceMeter->update(right, left);
			if (mFindStair->isFinding() || mDistanceMeter->getDistance() > STAIR_DISTANCE)
			{
				ev3_speaker_play_tone(NOTE_C4, DURATION);
				mState = UP_1ST_STAIR;
				mStateOverStair = FIND_STAIR;
			}
			break;

		case UP_1ST_STAIR:

			switch (mStateOverStair)
			{
			case FIND_STAIR:
				mBalancingRunnerZERO->move(direction, -1*MIDDLE);
				mMotorController->getEncoderCounts(right, left);
				mDistanceMeter->update(right, left);
				if (mDistanceMeter->getDistance() < LEAVE_DISTANCE)
				{
					ev3_speaker_play_tone(NOTE_D4, DURATION);
					mStateOverStair = ACCLERATION;
					mTailMovement->stateReset();
				}
				break;

			case ACCLERATION:

				mBalancingRunnerZERO->move(direction, MAXIMUM);
				mMotorController->getEncoderCounts(right, left);
				mDistanceMeter->update(right, left);
				if (mDistanceMeter->getDistance() > CENTER_DISTANCE)
				{
					mStateOverStair = UP_COMPLETE;
					ev3_speaker_play_tone(NOTE_E4, DURATION);
				}
				break;

			case UP_COMPLETE:

				mBalancingRunnerZERO->move(direction, STOP);
				mState = TURN_1ST;
				break;

			default:
				mStateOverStair = FIND_STAIR;
				break;

			}
			break;

		case TURN_1ST:

			mBalancingRunnerZERO->move(direction, STOP);
			break;

		default:
			mState = PREPARE_FIND_STAIR;
			break;
		}

		if (mState == STAIR_COMPLETE)return 1;
		return 0;
	}
}
