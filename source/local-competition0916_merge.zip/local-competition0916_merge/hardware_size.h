#ifndef HARDWARE_SIZE_H
#define HARDWARE_SIZE_H

// ポート設定
static const float WHEEL_DIAMETER_MM = 82.f;
static const float WHEEL_DISTANCE_MM = 160.f;

#endif
